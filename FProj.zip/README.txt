When testing the StudentUI.py, please make sure to change the client_id and client_secret to match the ones from the fénix aplication.Also make sure to make the fénix aplication redirect link in the following format: "http://<your ipv4 adress>/callback"

Every python script available must be executed for a well functioning app
To acess the Student website, use the port 8006(exclusive to smartphones)
to acess the Admin website,use the port 8000

Thank you for your pacience.
